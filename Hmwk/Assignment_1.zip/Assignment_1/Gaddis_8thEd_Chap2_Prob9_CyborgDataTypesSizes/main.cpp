/* 
 * File:   main.cpp
 * Author: Elijah De Vera
 * Created on January 5, 2021, 12:36 AM
 * Purpose: Sales Prediction
 */

//System Libraries
#include <iostream> //I/O Library
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversion, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables

    //Initialize Variables

    //Map Inputs to Outputs -> Process

    //Display Inputs/Outputs
    cout<< "The size of a char is " << sizeof(char) << " bytes. \n";
    cout<< "The size of an int is " << sizeof(int) << " bytes. \n";
    cout<< "The size of a float is " << sizeof(float) << " bytes. \n";
    cout<< "The size of a double is " << sizeof(double) << " bytes. \n";
    
    
    // Exit the Program - Cleanup
    return 0;
}

